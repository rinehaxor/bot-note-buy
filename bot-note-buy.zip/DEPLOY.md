# 🚀 Panduan Deploy Bot ke VPS

## 📦 File yang Sudah Dibuat

- **`bot-note-buy.zip`** - Project lengkap (index-nodejs.js, package.json, .env, credentials, dll)
- **`deploy-vps.sh`** - Script otomatis untuk setup di VPS

---

## 📋 Langkah Deploy ke VPS

### Step 1: Upload File ke VPS

Gunakan **FileZilla**, **WinSCP**, atau command SCP manual:

```bash
# Via SCP (jika tidak pakai FileZilla)
scp bot-note-buy.zip ubuntu@43.134.43.235:~/
scp deploy-vps.sh ubuntu@43.134.43.235:~/
```

Atau drag & drop pakai FileZilla ke folder `/home/ubuntu/`

---

### Step 2: SSH ke VPS

```bash
ssh ubuntu@43.134.43.235 -p 22
```

---

### Step 3: Jalankan Script Deploy

```bash
# Berikan permission execute
chmod +x deploy-vps.sh

# Jalankan script
./deploy-vps.sh
```

Script akan otomatis:

- ✅ Install Node.js (jika belum ada)
- ✅ Install unzip
- ✅ Extract project
- ✅ Install dependencies (`npm install`)
- ✅ Install PM2
- ✅ Start bot dengan PM2
- ✅ Setup auto-restart saat VPS reboot

---

### Step 4: Verifikasi Bot Running

```bash
# Cek status bot
pm2 status

# Lihat logs
pm2 logs telegram-bot

# Test bot di Telegram
# Kirim: /start
```

---

## 🔧 Perintah PM2 Berguna

```bash
pm2 status               # Lihat status semua process
pm2 logs telegram-bot    # Lihat logs real-time
pm2 restart telegram-bot # Restart bot
pm2 stop telegram-bot    # Stop bot
pm2 start telegram-bot   # Start bot lagi
pm2 delete telegram-bot  # Hapus dari PM2
pm2 save                 # Save konfigurasi saat ini
```

---

## ✅ Selesai!

Bot sekarang:

- 🟢 Running 24/7 di VPS
- 🔄 Auto-restart jika error
- 🚀 Auto-start saat VPS reboot
- 📊 Bisa monitor dengan PM2

---

## 🐛 Troubleshooting

### Bot tidak start

```bash
# Cek error di logs
pm2 logs telegram-bot --lines 50

# Delete dan start ulang
pm2 delete telegram-bot
pm2 start index-nodejs.js --name telegram-bot
```

### Update kode

```bash
# Upload file baru ke VPS, lalu:
cd ~/bot-note-buy
pm2 restart telegram-bot
```

### Port sudah dipakai

```bash
# Cek process yang pakai port
sudo lsof -i :3000  # ganti 3000 dengan port yang error

# Kill process jika perlu
pm2 delete telegram-bot
```

---

Selamat! Bot Anda sudah production ready! 🎉
