require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const { GoogleSpreadsheet } = require('google-spreadsheet');
const { JWT } = require('google-auth-library');

// ===== CONFIG =====
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const SPREADSHEET_ID = process.env.SPREADSHEET_ID;
const SEED_SHEET_NAME = process.env.SEED_SHEET_NAME || 'SEED';
const TZ = process.env.TZ || 'Asia/Jakarta';

// Google Service Account credentials
const GOOGLE_SERVICE_ACCOUNT_EMAIL = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
const GOOGLE_PRIVATE_KEY = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n');

// In-memory storage untuk undo (bisa diganti dengan file/database)
const userLastActions = {};

// ===== INIT BOT =====
const bot = new TelegramBot(TELEGRAM_BOT_TOKEN, { polling: true });
console.log('🤖 Bot started successfully!');

// ===== GOOGLE SHEETS HELPERS =====
async function getSheet() {
   // Create JWT auth client untuk google-spreadsheet v4
   const serviceAccountAuth = new JWT({
      email: GOOGLE_SERVICE_ACCOUNT_EMAIL,
      key: GOOGLE_PRIVATE_KEY,
      scopes: ['https://www.googleapis.com/auth/spreadsheets'],
   });

   const doc = new GoogleSpreadsheet(SPREADSHEET_ID, serviceAccountAuth);
   await doc.loadInfo();
   return doc;
}

function getMonthSheetName() {
   const bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
   const now = new Date();
   const m = now.getMonth();
   const yy = String(now.getFullYear()).slice(-2);
   return `${bulan[m]}${yy}`;
}

async function getOrCreateMonthSheet(doc, sheetName) {
   let sheet = doc.sheetsByTitle[sheetName];
   if (sheet) return sheet;

   // Cari seed sheet
   const seedSheet = doc.sheetsByTitle[SEED_SHEET_NAME];
   if (!seedSheet) {
      throw new Error(`Seed sheet tidak ditemukan: ${SEED_SHEET_NAME}`);
   }

   // Duplicate seed sheet
   sheet = await seedSheet.duplicate({ title: sheetName });

   // Hapus data contoh (baris 2 dst)
   await sheet.loadCells();
   const rows = await sheet.getRows();
   if (rows.length > 0) {
      for (const row of rows) {
         await row.delete();
      }
   }

   return sheet;
}

function getNextNo(rows) {
   if (rows.length === 0) return 1;

   const lastRow = rows[rows.length - 1];
   const lastNo = parseInt(lastRow.get('No') || lastRow._rawData[0]);

   if (!isNaN(lastNo) && lastNo > 0) return lastNo + 1;
   return rows.length + 1;
}

// ===== FORMAT HELPERS =====
function parseAdd(text) {
   const raw = text.slice(4).trim(); // setelah "/add"
   const parts = raw
      .split('|')
      .map((s) => s.trim())
      .filter(Boolean);

   if (parts.length < 3) return { ok: false };

   const aplikasi = parts[0];
   const jenis = parts[1];
   const laba = parseIDR(parts[2]);

   if (!aplikasi || !jenis || !isFinite(laba) || laba <= 0) {
      return { ok: false };
   }

   return { ok: true, aplikasi, jenis, laba };
}

function parseIDR(s) {
   const cleaned = String(s).replace(/\s/g, '').replace(/rp/gi, '').replace(/\./g, '').replace(/,/g, '.');
   return Math.round(Number(cleaned));
}

function formatIDR(n) {
   return 'Rp ' + Number(n).toLocaleString('id-ID');
}

function formatDate(date = new Date()) {
   const d = String(date.getDate()).padStart(2, '0');
   const m = String(date.getMonth() + 1).padStart(2, '0');
   const y = date.getFullYear();
   return `${d}/${m}/${y}`;
}

// ===== BOT COMMANDS =====

// /start
bot.onText(/\/start/, (msg) => {
   const chatId = msg.chat.id;
   const helpText = `Perintah:
/add Aplikasi | Jenis | Laba
/today
/undo

Contoh:
/add Capcut | 1 bulan | 8000
/add Canva Designer | 1 bulan | 5000`;

   bot.sendMessage(chatId, helpText);
});

// /add
bot.onText(/\/add (.+)/, async (msg, match) => {
   const chatId = msg.chat.id;
   const userId = msg.from.id;
   const text = msg.text;

   try {
      const parsed = parseAdd(text);

      if (!parsed.ok) {
         return bot.sendMessage(chatId, 'Format salah.\nPakai:\n/add Aplikasi | Jenis | Laba\nContoh: /add Canva | lifetime | 15000');
      }

      // Get Google Sheet
      const doc = await getSheet();
      const sheetName = SEED_SHEET_NAME; // Pakai sheet Bot langsung
      const sheet = doc.sheetsByTitle[sheetName];

      if (!sheet) {
         throw new Error(`Sheet tidak ditemukan: ${sheetName}`);
      }

      // Get existing rows
      const rows = await sheet.getRows();
      const nextNo = getNextNo(rows);
      const tanggal = formatDate();

      // Add new row
      await sheet.addRow({
         No: nextNo,
         Tanggal: tanggal,
         Aplikasi: parsed.aplikasi,
         Jenis: parsed.jenis,
         Laba: parsed.laba,
      });

      // Save untuk undo
      userLastActions[userId] = {
         sheetName: sheetName,
         rowNo: nextNo,
      };

      bot.sendMessage(chatId, `✅ Tercatat (${sheetName}) #${nextNo}\n${tanggal}\n${parsed.aplikasi} | ${parsed.jenis} | ${formatIDR(parsed.laba)}`);
   } catch (error) {
      console.error('Error adding row:', error);
      bot.sendMessage(chatId, '❌ Gagal menambahkan data. Error: ' + error.message);
   }
});

// /today
bot.onText(/\/today/, async (msg) => {
   const chatId = msg.chat.id;

   try {
      const doc = await getSheet();
      const sheetName = SEED_SHEET_NAME; // Pakai sheet Bot langsung
      const sheet = doc.sheetsByTitle[sheetName];

      if (!sheet) {
         throw new Error(`Sheet tidak ditemukan: ${sheetName}`);
      }

      const today = formatDate();
      const rows = await sheet.getRows();

      let total = 0;
      const lines = [];

      for (const row of rows) {
         const tanggal = row.get('Tanggal');
         if (tanggal !== today) continue;

         const no = row.get('No') || row._rawData[0];
         const app = row.get('Aplikasi') || row._rawData[2];
         const jenis = row.get('Jenis') || row._rawData[3];
         const laba = parseIDR(row.get('Laba') || row._rawData[4]);

         total += laba;
         lines.push(`#${no} ${app} | ${jenis} | ${formatIDR(laba)}`);
      }

      if (lines.length === 0) {
         return bot.sendMessage(chatId, `Belum ada transaksi hari ini (${today}) di tab ${sheetName}.`);
      }

      bot.sendMessage(chatId, `📌 Hari ini (${today}) [${sheetName}]\n${lines.join('\n')}\n\nTotal: ${formatIDR(total)}`);
   } catch (error) {
      console.error('Error getting today:', error);
      bot.sendMessage(chatId, '❌ Gagal mengambil data. Error: ' + error.message);
   }
});

// /undo
bot.onText(/\/undo/, async (msg) => {
   const chatId = msg.chat.id;
   const userId = msg.from.id;

   try {
      const lastAction = userLastActions[userId];

      if (!lastAction) {
         return bot.sendMessage(chatId, 'Tidak ada entry yang bisa di-undo.');
      }

      const doc = await getSheet();
      const sheet = doc.sheetsByTitle[lastAction.sheetName];

      if (!sheet) {
         return bot.sendMessage(chatId, 'Sheet undo tidak ditemukan: ' + lastAction.sheetName);
      }

      const rows = await sheet.getRows();

      // Cari row dengan No yang sesuai
      const rowToDelete = rows.find((row) => {
         const no = parseInt(row.get('No') || row._rawData[0]);
         return no === lastAction.rowNo;
      });

      if (!rowToDelete) {
         return bot.sendMessage(chatId, 'Entry terakhir sudah berubah, undo dibatalkan.');
      }

      await rowToDelete.delete();

      // Clear undo data
      delete userLastActions[userId];

      bot.sendMessage(chatId, `↩️ Undo sukses: hapus 1 entry terakhir di tab ${lastAction.sheetName}.`);
   } catch (error) {
      console.error('Error undo:', error);
      bot.sendMessage(chatId, '❌ Gagal undo. Error: ' + error.message);
   }
});

// Error handling
bot.on('polling_error', (error) => {
   console.error('Polling error:', error);
});

console.log('✅ Bot is running and waiting for messages...');
